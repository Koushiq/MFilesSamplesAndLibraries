# Sending commands from the client to the server

Creates two buttons in the M-Files client (either Desktop or Web Access).  Clicking each of the buttons executes a Vault Extension Method on the server, passing content to it and receiving content back.  The returned content is displayed in a messagebox on screen.

More information is available within the [M-Files Developer Portal](http://developer.m-files.com/Samples-And-Libraries/Samples/User-Interface-Extensibility-Framework/Client-To-Server-Communication/).
